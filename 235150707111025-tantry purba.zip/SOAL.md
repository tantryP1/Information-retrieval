# CLAUDE TASK

## Klasifikasi Sentimen Data Twitter

Dalam tugas ini, kita akan menggunakan data komen twitter untuk mengklasifikasikan atau mengkategorikan data tersebut menjadi beberapa klasifikasi sentimen, dimana sentimen adalah pendapat atau pandangan yg didasarkan pd perasaan yg berlebih-lebihan thd sesuatu.

### Latar Belakang (Overview)

Dalam kompetisi ini, mahasiswa ditantang untuk membangun model pembelajaran mesin yang mampu melakukan klasifikasi terhadap data yang disediakan. Dataset ini berisi 40.000 sampel, dengan berbagai fitur yang mewakili karakteristik dari setiap entri.

Tugas utama peserta adalah memprediksi label kelas dari data uji (test set) seakurat mungkin berdasarkan pola yang dipelajari dari data latih (training set).

### Informasi Dataset

- Total data: 40.000 baris
- Data latih (train): 28.000 baris
- Data uji (test): 12.000 baris
- Format data: CSV
- Target: kolom label (nama kolom target dapat disesuaikan)

Peserta dapat menggunakan data latih untuk membangun, melatih, dan memvalidasi model mereka. Prediksi untuk data uji harus disimpan dalam format [sample_submission.csv](./data/sample_submission.csv) yang disediakan. Gunakan data [train.csv](./data/train.csv) sebagai data latih

### Catatan Tambahan

- Peserta bebas menggunakan model apa pun (klasik atau deep learning).
- Tidak diperbolehkan menggunakan data eksternal.
- Penilaian akhir akan dilakukan berdasarkan Private Leaderboard.

### Evaluation

Kompetisi ini menggunakan metrik F1-Score (Macro Average) sebagai dasar penilaian.

### Format Submission

File hasil prediksi harus disimpan dalam format .csv dengan struktur berikut:
```csv
tweet_id,sentiment
1,class_1   
2,class_2
3,class_3
...
```
Pastikan urutan id sama dengan yang ada pada file [test.csv](./data/test.csv)

## Code Convention

- Gunakan [main.ipynb](./main.ipynb) sebagai tempat kerja
- Pisahkan setiap proses dalam 1 cell, terapkan prinsip `single responsibility principle` tiap cell, fungsi/method, dan class
- Sebelum menulis kode dalam cell, jelaskan proses apa yang akan dilakukan dalam 2 kategori: penjelasan panjang dan deskripsi dan penjelasan singkat dan simpel. Penjelasan diletakkan dalam markdown sebelum cell dan gunakan bahasa mahasiswa tanpa tanda -- 
- Laptop ini tidak menggunakan NVIDIA GPU